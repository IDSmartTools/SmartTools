1.关闭InDesign
2.解压压缩包
3.复制“win64 CC20XX”文件夹到“****\Adobe InDesign 20XX\Plug-Ins”
4.复制“miniz.dll”和“tinyxml2.dll”到“****\Adobe InDesign 20XX”
5.启动InDesign


1. Turn off InDesign
2. Extract the archive
3. Copy "win64 CC20XX" folder to "****\Adobe InDesign 20XX\Plug-Ins"
4. Copy "miniz.dll" and "tinyxml2.dll" to "****\Adobe InDesign 20XX"
5. Start InDesign